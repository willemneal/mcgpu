var structsource__energy__struct =
[
    [ "espc", "structsource__energy__struct.html#a66db20f7a335eb91023e0d1191730b42", null ],
    [ "espc_alias", "structsource__energy__struct.html#a8504b5d435cbf4feef2af89c0fd3f829", null ],
    [ "espc_cutoff", "structsource__energy__struct.html#a39635503e804b265f76d3a0f7edb2a9f", null ],
    [ "num_bins_espc", "structsource__energy__struct.html#a559e19adbc83b2aea219281e14f82bb1", null ]
];