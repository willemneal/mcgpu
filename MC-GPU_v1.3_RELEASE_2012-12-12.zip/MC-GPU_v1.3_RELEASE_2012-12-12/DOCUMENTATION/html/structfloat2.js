var structfloat2 =
[
    [ "x", "structfloat2.html#a0bb68b4a8de04ffea5f7aae53c48a613", null ],
    [ "y", "structfloat2.html#a0f1298f22c4ee20a369cd3b9c25b2cc6", null ]
];