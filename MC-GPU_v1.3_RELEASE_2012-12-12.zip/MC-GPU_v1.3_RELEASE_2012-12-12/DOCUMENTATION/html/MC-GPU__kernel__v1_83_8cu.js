var MC-GPU__kernel__v1_83_8cu =
[
    [ "a1_RANECU", "MC-GPU__kernel__v1_83_8cu.html#afd7d5320ad79ad99c8d230f3a730141d", null ],
    [ "a2_RANECU", "MC-GPU__kernel__v1_83_8cu.html#a527a42aca15fac6a1cab1116a72eb8ca", null ],
    [ "LEAP_DISTANCE", "MC-GPU__kernel__v1_83_8cu.html#a3ab75c5bf72afd4a9b0255f61bd95704", null ],
    [ "m1_RANECU", "MC-GPU__kernel__v1_83_8cu.html#aa7d2cfcd3830e91736ca79f4bfdfb5d2", null ],
    [ "m2_RANECU", "MC-GPU__kernel__v1_83_8cu.html#a9872bd70bdcc27f56bc025f291b7d6c2", null ],
    [ "abMODm", "MC-GPU__kernel__v1_83_8cu.html#ae9061f4314474bf4415200a5cb115397", null ],
    [ "GCOa", "MC-GPU__kernel__v1_83_8cu.html#a6f212862e7fba1553ec9495f05443b2c", null ],
    [ "GRAa", "MC-GPU__kernel__v1_83_8cu.html#a5cafd4ebb3d155746b16ca7d231ecad1", null ],
    [ "init_PRNG", "MC-GPU__kernel__v1_83_8cu.html#ae7bd0b93b4d5eedb15822fa0ef622b48", null ],
    [ "locate_voxel", "MC-GPU__kernel__v1_83_8cu.html#a562dba755f1abdb20b1088d3121f4326", null ],
    [ "move_to_bbox", "MC-GPU__kernel__v1_83_8cu.html#a047931bac84f3bce50dc13061371e765", null ],
    [ "ranecu", "MC-GPU__kernel__v1_83_8cu.html#a3b57f2faa5765ceba5d352641ca72a9f", null ],
    [ "ranecu_double", "MC-GPU__kernel__v1_83_8cu.html#a74c4894502584f8fb113e04b759a6c55", null ],
    [ "rotate_double", "MC-GPU__kernel__v1_83_8cu.html#a94ad9ed794eb8fd696e7e357ae391765", null ],
    [ "source", "MC-GPU__kernel__v1_83_8cu.html#a6807df36f6f2501a9f57ea4fce81b4f2", null ],
    [ "tally_image", "MC-GPU__kernel__v1_83_8cu.html#aac14e3b20e073c6b169f2bd5c23da281", null ],
    [ "tally_materials_dose", "MC-GPU__kernel__v1_83_8cu.html#a45a0719009ba55cca7af72f08f1090fb", null ],
    [ "tally_voxel_energy_deposition", "MC-GPU__kernel__v1_83_8cu.html#aac6cb77943874a858ac5a79cbd58f1e7", null ],
    [ "track_particles", "MC-GPU__kernel__v1_83_8cu.html#ab1e2e311c809fe74d093498e53c9c954", null ]
];