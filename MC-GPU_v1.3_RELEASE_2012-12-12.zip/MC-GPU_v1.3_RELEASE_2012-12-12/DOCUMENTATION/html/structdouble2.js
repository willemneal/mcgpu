var structdouble2 =
[
    [ "x", "structdouble2.html#a9b503609bcf82337e39ac766fe39214c", null ],
    [ "y", "structdouble2.html#a7115f6cec9175e255c655238e3478a88", null ]
];