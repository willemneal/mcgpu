var structshort3 =
[
    [ "x", "structshort3.html#a5d5d88cacca4de50a2334be0033a126a", null ],
    [ "y", "structshort3.html#a6056b3f7d064291aaf9121575ec83866", null ],
    [ "z", "structshort3.html#a803658b690ee5726c60a2b99b99b9143", null ]
];