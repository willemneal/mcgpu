var structcompton__struct =
[
    [ "fco", "structcompton__struct.html#a181131326c64f04da9eb7f199604371e", null ],
    [ "fj0", "structcompton__struct.html#a2acdfc304123cea06abea723b5b28d38", null ],
    [ "noscco", "structcompton__struct.html#aef81eb007c90d13552ea867912f0d2c3", null ],
    [ "uico", "structcompton__struct.html#a32dcebc4af75e0620abed9c32ffc2bdd", null ]
];