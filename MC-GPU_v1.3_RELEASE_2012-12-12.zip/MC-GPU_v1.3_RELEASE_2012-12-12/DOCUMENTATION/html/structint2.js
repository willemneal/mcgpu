var structint2 =
[
    [ "x", "structint2.html#a2b4908d6f7ae421393c0ec0233e90551", null ],
    [ "y", "structint2.html#a3d7ff3bd7734f8c2f38613a4da5e6c83", null ]
];