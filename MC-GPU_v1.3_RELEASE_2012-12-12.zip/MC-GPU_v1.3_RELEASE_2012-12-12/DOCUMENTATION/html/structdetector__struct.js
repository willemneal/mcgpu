var structdetector__struct =
[
    [ "center", "structdetector__struct.html#a1f0ce65af62c45925dfc96de3b796474", null ],
    [ "corner_min_rotated_to_Y", "structdetector__struct.html#a824e406500b0d8ca59ca96985a599b8b", null ],
    [ "height_Z", "structdetector__struct.html#af61592c77c6da548fff31215bf956dd8", null ],
    [ "inv_pixel_size_X", "structdetector__struct.html#a3c6f9e59e89db06211ccea63287e2826", null ],
    [ "inv_pixel_size_Z", "structdetector__struct.html#aa91fc94f674ad7af8eca577f4d8cd22b", null ],
    [ "num_pixels", "structdetector__struct.html#a1a30e7168cba7eebe918ab39bb408dce", null ],
    [ "rot_inv", "structdetector__struct.html#a05b03d920370a5925ea56932e5953a69", null ],
    [ "rotation_flag", "structdetector__struct.html#adbe41a01886ae097dac0fa908551d035", null ],
    [ "sdd", "structdetector__struct.html#a781104d94879829947e6c863ee17abb5", null ],
    [ "total_num_pixels", "structdetector__struct.html#ac26d0b66ebf521346d8ba07609340ea6", null ],
    [ "width_X", "structdetector__struct.html#a1f67c512205953e75552865ae7a2490a", null ]
];