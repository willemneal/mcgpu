var structint3 =
[
    [ "x", "structint3.html#a0a4ad50a155a35fa938ce6f16930affa", null ],
    [ "y", "structint3.html#a5d95e23491677d61019f0354b16adca9", null ],
    [ "z", "structint3.html#a5cd5a3c388fa28814e3496ef07c39360", null ]
];