var annotated =
[
    [ "compton_struct", "structcompton__struct.html", "structcompton__struct" ],
    [ "detector_struct", "structdetector__struct.html", "structdetector__struct" ],
    [ "double2", "structdouble2.html", "structdouble2" ],
    [ "double3", "structdouble3.html", "structdouble3" ],
    [ "float2", "structfloat2.html", "structfloat2" ],
    [ "float3", "structfloat3.html", "structfloat3" ],
    [ "int2", "structint2.html", "structint2" ],
    [ "int3", "structint3.html", "structint3" ],
    [ "linear_interp", "structlinear__interp.html", "structlinear__interp" ],
    [ "rayleigh_struct", "structrayleigh__struct.html", "structrayleigh__struct" ],
    [ "short3", "structshort3.html", "structshort3" ],
    [ "source_energy_struct", "structsource__energy__struct.html", "structsource__energy__struct" ],
    [ "source_struct", "structsource__struct.html", "structsource__struct" ],
    [ "ulonglong2", "structulonglong2.html", "structulonglong2" ],
    [ "voxel_struct", "structvoxel__struct.html", "structvoxel__struct" ]
];