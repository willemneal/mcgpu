var structdouble3 =
[
    [ "x", "structdouble3.html#ad0570a8f409c151da3737b52cd1ee0a7", null ],
    [ "y", "structdouble3.html#ab6fe34e5dcee27325269b48655139159", null ],
    [ "z", "structdouble3.html#a44d35dc88f287935fe8a767e0b4b8d00", null ]
];