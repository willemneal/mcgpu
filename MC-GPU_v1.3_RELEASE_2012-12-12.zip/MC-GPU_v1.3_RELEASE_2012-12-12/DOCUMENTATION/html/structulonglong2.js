var structulonglong2 =
[
    [ "x", "structulonglong2.html#a0d94e96b26765bf28a1a4b76391b88bb", null ],
    [ "y", "structulonglong2.html#a8453eaa1efda22c449296aa2ebcf0c7f", null ]
];