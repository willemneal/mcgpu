var structlinear__interp =
[
    [ "e0", "structlinear__interp.html#ac07eade974afb1b75d16516d1eb55a33", null ],
    [ "ide", "structlinear__interp.html#a4b743ecf01ca7d075cc6b36b9ce2f0a1", null ],
    [ "num_values", "structlinear__interp.html#a2bea2f84374be1b9afd5d896b16a7a46", null ]
];