var MC-GPU__v1_83_8cu =
[
    [ "fgets_trimmed", "MC-GPU__v1_83_8cu.html#aea168bca1466813e03b649931a4f670f", null ],
    [ "init_energy_spectrum", "MC-GPU__v1_83_8cu.html#ac1d6abb26890276f529eed6b7ceafe89", null ],
    [ "IRND0", "MC-GPU__v1_83_8cu.html#ac2eacae33c0451f6a23fdf1101c6ca11", null ],
    [ "load_material", "MC-GPU__v1_83_8cu.html#a55f3171a6cdb59fc43e65aa19c676d80", null ],
    [ "load_voxels", "MC-GPU__v1_83_8cu.html#aed61d205baa31cea69768bbd68c062c6", null ],
    [ "main", "MC-GPU__v1_83_8cu.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "read_input", "MC-GPU__v1_83_8cu.html#a04125b2129832959744717839c968ebb", null ],
    [ "report_image", "MC-GPU__v1_83_8cu.html#aa23f71412757b1d0e1d4c00e6b8a0c18", null ],
    [ "report_materials_dose", "MC-GPU__v1_83_8cu.html#aa02ffc836f2b6f9de5386cadb11e30b7", null ],
    [ "report_voxels_dose", "MC-GPU__v1_83_8cu.html#aeceeb305fc1d995c4730e0fcedf10d0c", null ],
    [ "seeki_walker", "MC-GPU__v1_83_8cu.html#a0b858ab906084d4426bfe5b522074e2c", null ],
    [ "set_CT_trajectory", "MC-GPU__v1_83_8cu.html#a5f62e6c0430761bba20f1e546d396a27", null ],
    [ "trim_name", "MC-GPU__v1_83_8cu.html#a96dba25b308814b25fbae71e27617f12", null ],
    [ "update_seed_PRNG", "MC-GPU__v1_83_8cu.html#a6577c51b64b94b13c4e95df776275b5a", null ]
];