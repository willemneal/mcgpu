var structvoxel__struct =
[
    [ "inv_voxel_size", "structvoxel__struct.html#ad1468b63b2b99455904cc43e9058d5c1", null ],
    [ "num_voxels", "structvoxel__struct.html#adeed35f7e44a7cfb2891001a1a68f868", null ],
    [ "size_bbox", "structvoxel__struct.html#abdd12181cdff77da8b880eedf1d81e33", null ]
];