var files =
[
    [ "MC-GPU_kernel_v1.3.cu", "MC-GPU__kernel__v1_83_8cu.html", "MC-GPU__kernel__v1_83_8cu" ],
    [ "MC-GPU_v1.3.cu", "MC-GPU__v1_83_8cu.html", "MC-GPU__v1_83_8cu" ],
    [ "MC-GPU_v1.3.h", "MC-GPU__v1_83_8h.html", "MC-GPU__v1_83_8h" ]
];