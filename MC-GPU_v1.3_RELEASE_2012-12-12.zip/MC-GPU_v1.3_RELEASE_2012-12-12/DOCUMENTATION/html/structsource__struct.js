var structsource__struct =
[
    [ "cos_theta_low", "structsource__struct.html#ad3b7a93633ec87d036453e54e7e7abad", null ],
    [ "D_cos_theta", "structsource__struct.html#a942289f702f8fc1c6acd411c8ff19efe", null ],
    [ "D_phi", "structsource__struct.html#a01b06b35c2bc440ad0091dddde0cad06", null ],
    [ "direction", "structsource__struct.html#ae1a18388dff97d101b36aeaba9bd363a", null ],
    [ "max_height_at_y1cm", "structsource__struct.html#ab1bdb59150b1b055e9149461bc090cf4", null ],
    [ "phi_low", "structsource__struct.html#a22bb360d294d1a3236e8ba8c4b6d06aa", null ],
    [ "position", "structsource__struct.html#af0d7a559e56da9df6b01dda2ac95a787", null ],
    [ "rot_fan", "structsource__struct.html#a0fcd590a93652a70c73fbc8577d36cfb", null ]
];